# Jarvis for Android

Say "Jarvis", wait for the beep, then give a command. Claude reads the screen and taps, types, scrolls, calls and opens apps for you.

## Build
1. Install Android Studio. File > Open > this folder (it creates the Gradle wrapper for you).
2. Get a free AccessKey at console.picovoice.ai (wake word "Jarvis" is built in).
3. Get an Anthropic API key at console.anthropic.com.
4. Run on your phone (USB debugging on).

## First run (in the app, in order)
1. Grant permissions.
2. Enable "Jarvis" under Accessibility (Android may warn that the setting is restricted: App info > three dots > Allow restricted settings).
3. Allow display over other apps (lets Jarvis open apps from the background).
4. Paste both keys and tap Start Jarvis.

Install the same APK on your second phone and repeat. Each phone runs its own Jarvis.

## Notes
- Wake word is "Jarvis". "Hey Jarvis" needs a custom keyword trained in the Picovoice console; drop the .ppn in assets and use setKeywordPath().
- Banking and some secure apps block accessibility reading by design.
- Your command and screen text are sent to the Claude API. Keep your API key private.

## Offline mode (no internet)
When there is no internet (or Claude can't be reached) Jarvis switches automatically:
- Hearing: Vosk (on-device).
- Thinking: fixed voice commands run instantly (open app, call digits, back/home/recents, notifications, scroll, tap X, type X, search X, flashlight on/off, time, date, read screen). Anything else is answered by Gemma running on the phone.
- Speaking: Android text-to-speech with an offline voice.

One-time setup (do it while online):
1. Install and open the app once, so its folder exists.
2. Voice pack: Settings > System > Language > Text-to-speech > Google > Install voice data, then download your language.
3. Hearing model: download "vosk-model-small-en-us-0.15" from alphacephei.com/vosk/models, unzip, rename the folder to `vosk`.
4. Brain model: download a MediaPipe-compatible Gemma .task file (for example Gemma 3 1B int4 from the litert-community page on Hugging Face; you must accept Google's licence) and rename it `gemma.task`.
5. Copy both to the phone with a PC:
   adb push vosk /sdcard/Android/data/com.jarvis.app/files/vosk
   adb push gemma.task /sdcard/Android/data/com.jarvis.app/files/gemma.task

Offline limits: a small on-device model cannot run multi-step app tasks the way Claude can, so offline control is the fixed command list above. Phone-wide Q&A works but is less accurate. Calling contacts by name is not included (numbers only).

## Commands (examples)
Online, Claude handles almost any request in plain speech: "call Mom", "set an alarm for 6:30 am", "open Instagram and like this post", "comment nice shot on this", "search YouTube for lo-fi music", "what is the capital of France" (web search is used for current facts; enable web search in the Anthropic console).
Offline, these fixed phrases work: "call <contact name or digits>", "set an alarm for seven thirty a m", "open <any app>", "like this post", "comment <text>", "search YouTube for <text>", "search for <text>", "tap <text>", "type <text>", plus the earlier ones. Other questions are answered by Gemma.

## Voice
Online replies use ElevenLabs (paste your key; blank voice ID uses the premade male voice "Adam", or paste any voice ID from your ElevenLabs library). ElevenLabs needs internet and costs credits. Offline, replies use the phone's own voice: install a male voice in Settings > Text-to-speech.
Like and comment work by finding buttons labelled "Like", "Comment", "Post" or "Send", so results vary by app and language. Contact names depend on speech recognition hearing them correctly.

## Confirmation before sending
Whenever Jarvis is about to tap Send, Post, Reply, Publish, Tweet or Submit (or Comment with text already typed), it reads out the text and asks you to confirm. Say "yes" to send. Anything else, silence, or no answer within a few seconds cancels. This is enforced in code, online and offline.
It only catches taps on those buttons. Pressing Enter on the keyboard to send is not covered, so the online prompt tells Claude to tap the button instead.

## Customize by voice (no rebuild)
- Teach a command (needs internet once, then works offline): "Jarvis, add a command: when I say good night, set an alarm for seven and open YouTube". Jarvis repeats it back and saves it on your yes.
- Standing instructions: "From now on, keep answers very short" or "Remember that I like cricket scores".
- Manage: "list my commands", "forget command good night", "forget all notes".
- New abilities that need new code: say "feature request: ..." then tap "Copy my feature requests" in the app and send the text to Claude, who sends back a new project zip to rebuild.

## Build without a computer
Use GitHub in your phone browser: upload jarvis-android.zip to a new repo, add build.yml as .github/workflows/build.yml, run it on the Actions tab, then download the jarvis-apk artifact.
