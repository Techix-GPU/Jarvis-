package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.ServiceCompat
import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.io.File
import java.util.Locale
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

class JarvisService : Service() {
    private var wake: PorcupineManager? = null
    private var recognizer: SpeechRecognizer? = null
    private var voskModel: Model? = null
    private var speech: SpeechService? = null
    private lateinit var tts: TextToSpeech
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val confirmQ = LinkedBlockingQueue<Boolean>()
    @Volatile private var confirming = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis").setContentTitle("Jarvis is listening")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        ServiceCompat.startForeground(this, 1, n,
            if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale.getDefault()
                tts.voices?.firstOrNull {
                    it.locale.language == Locale.getDefault().language && !it.isNetworkConnectionRequired
                }?.let { tts.voice = it }
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { main.post { speechDone() } }
            override fun onDone(id: String?) { main.post { speechDone() } }
        })
        Confirm.handler = { prompt -> askConfirm(prompt) }

        val key = getSharedPreferences("j", 0).getString("pv", "") ?: ""
        wake = PorcupineManager.Builder()
            .setAccessKey(key)
            .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
            .build(this) { main.post { onWake() } }
        resumeWake()
    }

    private fun resumeWake() { try { wake?.start() } catch (_: Exception) {} }

    /** Called whenever a spoken reply finishes. During a confirmation, listen for yes/no instead of the wake word. */
    private fun speechDone() {
        if (confirming) {
            beep()
            main.postDelayed({ listenFor { t -> confirmQ.offer(t != null && Confirm.isYes(t)) } }, 250)
        } else resumeWake()
    }

    // Runs on a background thread (called from the agent): speak the question, wait for the answer.
    private fun askConfirm(prompt: String): Boolean {
        confirmQ.clear()
        confirming = true
        main.post { say(prompt) }
        val ok = confirmQ.poll(60, TimeUnit.SECONDS) ?: false
        confirming = false
        return ok
    }

    private fun phoneSay(text: String) { tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "reply") }

    // Online: ElevenLabs male voice. Offline or on any failure: the phone's own voice.
    private fun say(text: String) {
        if (!isOnline(this)) { phoneSay(text); return }
        scope.launch {
            val f = ElevenLabs.fetch(this@JarvisService, text)
            main.post { if (f == null) phoneSay(text) else play(f) }
        }
    }

    private fun play(f: File) {
        try {
            MediaPlayer().apply {
                setDataSource(f.path)
                setOnCompletionListener { it.release(); f.delete(); speechDone() }
                setOnErrorListener { mp, _, _ -> mp.release(); f.delete(); speechDone(); true }
                prepare(); start()
            }
        } catch (e: Exception) { speechDone() }
    }

    private fun beep() { ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150) }

    private fun onWake() {
        try { wake?.stop() } catch (_: Exception) {}
        beep()
        main.postDelayed({ listenFor { t -> if (t.isNullOrBlank()) resumeWake() else run(t) } }, 250)
    }

    private fun listenFor(onText: (String?) -> Unit) {
        if (isOnline(this)) listenOnline(onText) else listenOffline(onText)
    }

    private fun listenOnline(onText: (String?) -> Unit) {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    onText(r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
                }
                override fun onError(e: Int) {
                    if (e == SpeechRecognizer.ERROR_NETWORK || e == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                        e == SpeechRecognizer.ERROR_SERVER) listenOffline(onText) else onText(null)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            })
        }
    }

    private fun listenOffline(onText: (String?) -> Unit) {
        val dir = File(getExternalFilesDir(null), "vosk")
        if (!dir.exists()) {
            if (confirming) onText(null) else say("The offline voice model is not installed.")
            return
        }
        try {
            if (voskModel == null) voskModel = Model(dir.absolutePath)
            val ss = SpeechService(Recognizer(voskModel, 16000f), 16000f)
            speech = ss
            ss.startListening(object : org.vosk.android.RecognitionListener {
                override fun onPartialResult(h: String?) {}
                override fun onFinalResult(h: String?) {}
                override fun onResult(h: String?) {
                    val t = JSONObject(h ?: "{}").optString("text")
                    if (t.isNotBlank()) { ss.stop(); ss.shutdown(); speech = null; onText(t) }
                }
                override fun onError(e: Exception?) { ss.shutdown(); speech = null; onText(null) }
                override fun onTimeout() { ss.shutdown(); speech = null; onText(null) }
            }, 8000)
        } catch (e: Exception) { onText(null) }
    }

    private fun run(command: String) {
        scope.launch {
            val reply = try { Agent(this@JarvisService).run(command) } catch (e: Exception) { "Sorry, ${e.message}" }
            main.post { say(reply.ifBlank { "Done." }) }
        }
    }

    override fun onDestroy() {
        Confirm.handler = null
        try { wake?.stop(); wake?.delete() } catch (_: Exception) {}
        recognizer?.destroy(); speech?.shutdown(); tts.shutdown(); scope.cancel()
        super.onDestroy()
    }
}
