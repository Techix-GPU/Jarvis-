package com.jarvis.app

import android.content.Context
import android.provider.ContactsContract.CommonDataKinds.Phone

object Contacts {
    /** Returns the phone number of the best-matching contact name, or null. */
    fun find(ctx: Context, name: String): String? {
        val q = name.trim().lowercase()
        val c = ctx.contentResolver.query(Phone.CONTENT_URI,
            arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null) ?: return null
        var best: String? = null
        var score = 0
        c.use {
            while (it.moveToNext()) {
                val n = it.getString(0)?.lowercase() ?: continue
                val num = it.getString(1) ?: continue
                val s = when {
                    n == q -> 3
                    n.startsWith(q) -> 2
                    n.contains(q) || q.split(" ").all { w -> n.contains(w) } -> 1
                    else -> 0
                }
                if (s > score) { score = s; best = num }
            }
        }
        return best
    }
}
