package com.jarvis.app

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.provider.AlarmClock
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private const val MODEL = "claude-sonnet-5-5"

private const val SYSTEM = """You are Jarvis, a voice assistant that operates the user's Android phone.
Carry out the user's spoken command using the tools. Typical flow: open_app, read_screen, then tap / type_text / scroll / press, and read_screen again to confirm.
Prefer direct tools (call_contact, call, set_alarm, open_url) when they fit. To like a post tap 'Like'; to comment tap 'Comment', type_text, then tap 'Post' or 'Send'. To search YouTube use open_url with https://www.youtube.com/results?search_query=TERMS. Never use enter to send a message or comment; tap the Send or Post button instead. Tapping Send, Post or Reply asks the user to confirm by voice automatically; if the result says the user said no, stop. Answer general questions directly, and use web_search for current facts. Never pay, delete data, or send messages unless the user clearly asked.
Your final reply is spoken aloud: keep it to one short sentence."""

class Agent(private val ctx: Context) {
    private val http = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()
    private val userName = ctx.getSharedPreferences("j", 0).getString("name", "Shiba")
        ?.ifBlank { "Shiba" } ?: "Shiba"
    private val apiKey = ctx.getSharedPreferences("j", 0).getString("claude", "") ?: ""

    private fun tool(name: String, desc: String, vararg params: String) = JSONObject()
        .put("name", name).put("description", desc)
        .put("input_schema", JSONObject().put("type", "object")
            .put("properties", JSONObject().apply { params.forEach { put(it, JSONObject().put("type", "string")) } })
            .put("required", JSONArray(params.toList())))

    private val tools = JSONArray()
        .put(tool("open_app", "Open an installed app by its name", "name"))
        .put(tool("read_screen", "Return the text and buttons currently on screen"))
        .put(tool("tap", "Tap the on-screen element containing this text or description", "text"))
        .put(tool("type_text", "Type into the focused or first input field. enter='true' to submit afterwards", "text", "enter"))
        .put(tool("scroll", "Scroll the screen. direction is 'down' or 'up'", "direction"))
        .put(tool("press", "Press a system button: back, home, recents, notifications, quick_settings, enter", "button"))
        .put(tool("call", "Phone call to a number", "number"))
        .put(tool("open_url", "Open a web address or deep link", "url"))
        .put(tool("wait", "Wait a number of seconds for a screen to load", "seconds"))
        .put(tool("call_contact", "Phone call to a saved contact by name", "name"))
        .put(tool("set_alarm", "Set an alarm. hour is 0-23, minute is 0-59", "hour", "minute"))
        .put(JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 3))

    /** Online: Claude. Offline (or if Claude fails): on-device rules + local Gemma. */
    fun run(command: String): String {
        Custom.handle(ctx, this, command)?.let { return it }
        if (isOnline(ctx) && apiKey.isNotBlank()) {
            try { return runOnline(command) } catch (_: Exception) { }
        }
        return Offline(ctx, this).run(command)
    }

    private fun runOnline(command: String): String {
        val msgs = JSONArray().put(JSONObject().put("role", "user").put("content", command))
        repeat(15) {
            val content = call(msgs).getJSONArray("content")
            msgs.put(JSONObject().put("role", "assistant").put("content", content))
            val results = JSONArray()
            var text = ""
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                when (b.getString("type")) {
                    "text" -> text += b.getString("text")
                    "tool_use" -> results.put(JSONObject().put("type", "tool_result")
                        .put("tool_use_id", b.getString("id"))
                        .put("content", exec(b.getString("name"), b.getJSONObject("input"))))
                }
            }
            if (results.length() == 0) return text
            msgs.put(JSONObject().put("role", "user").put("content", results))
        }
        return "I stopped after too many steps."
    }

    /** One plain Claude request with no tools; returns the reply text. */
    fun oneShot(system: String, user: String): String {
        val body = JSONObject().put("model", MODEL).put("max_tokens", 600).put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
        val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey).header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw RuntimeException("API error ${r.code}")
            val c = JSONObject(r.body?.string() ?: "{}").getJSONArray("content")
            return (0 until c.length()).map { c.getJSONObject(it) }.filter { it.getString("type") == "text" }
                .joinToString("") { it.getString("text") }
        }
    }

    private fun call(msgs: JSONArray): JSONObject {
        val body = JSONObject().put("model", MODEL).put("max_tokens", 1024)
            .put("system", SYSTEM + "\nThe user's name is $userName. Do not say their name in replies unless they ask for it or it is truly needed." + Custom.noteBlock(ctx)).put("tools", tools).put("messages", msgs)
        val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey).header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            val s = r.body?.string() ?: ""
            if (!r.isSuccessful) throw RuntimeException("API error ${r.code}")
            return JSONObject(s)
        }
    }

    private fun launch(i: Intent): String {
        val svc = JarvisAccessibility.instance ?: return "Accessibility service is not enabled"
        svc.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); Thread.sleep(1500); return "ok"
    }

    private val sendWords = setOf("send", "post", "reply", "publish", "tweet", "submit")

    /** Anything that sends a comment or message needs a spoken yes first. */
    private fun gate(acc: JarvisAccessibility, text: String): Boolean {
        val t = text.lowercase().trim()
        val typed = acc.inputText().trim()
        val sending = t in sendWords || t.startsWith("send") || (t == "comment" && typed.isNotBlank())
        if (!sending) return true
        val prompt = if (typed.isBlank()) "I'm about to tap $text. Say yes to confirm."
            else "I'm about to tap $text with this text: ${typed.take(150)}. Say yes to confirm."
        return Confirm.ask(prompt)
    }

    fun exec(name: String, a: JSONObject): String {
        val acc = JarvisAccessibility.instance ?: return "Accessibility service is not enabled"
        return try {
            when (name) {
                "open_app" -> {
                    val pm = ctx.packageManager
                    val q = a.getString("name").lowercase()
                    val apps = pm.queryIntentActivities(
                        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                    val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
                        ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
                    val i = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
                    if (i == null) "No app named ${a.getString("name")}" else launch(i)
                }
                "read_screen" -> acc.dump()
                "tap" -> {
                    val t = a.getString("text")
                    if (!gate(acc, t)) "The user said no. Do not send it; tell them it was cancelled."
                    else if (acc.tap(t)) "tapped" else "not found"
                }
                "type_text" -> if (acc.type(a.getString("text"), a.optString("enter") == "true")) "typed" else "no input field"
                "scroll" -> if (acc.scroll(a.getString("direction") == "down")) "scrolled" else "nothing to scroll"
                "press" -> if (acc.press(a.getString("button"))) "pressed" else "failed"
                "call" -> launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + a.getString("number"))))
                "open_url" -> launch(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))))
                "call_contact" -> {
                    val n = Contacts.find(ctx, a.getString("name"))
                    if (n == null) "No contact matching ${a.getString("name")}"
                    else launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n))))
                }
                "set_alarm" -> launch(Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.getString("hour").toInt())
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.getString("minute").toInt())
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "wait" -> { Thread.sleep((a.optString("seconds").toLongOrNull() ?: 1L).coerceIn(1, 10) * 1000); "waited" }
                else -> "unknown tool"
            }
        } catch (e: Exception) { "error: ${e.message}" }
    }
}

fun isOnline(ctx: Context): Boolean {
    val cm = ctx.getSystemService(ConnectivityManager::class.java)
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}
