package com.jarvis.app

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/** On-device Gemma via MediaPipe. Needs gemma.task in the app's files folder. */
object LocalLlm {
    private var llm: LlmInference? = null

    fun available(ctx: Context) = File(ctx.getExternalFilesDir(null), "gemma.task").exists()

    @Synchronized
    private fun get(ctx: Context): LlmInference? {
        llm?.let { return it }
        val f = File(ctx.getExternalFilesDir(null), "gemma.task")
        if (!f.exists()) return null
        llm = LlmInference.createFromOptions(ctx,
            LlmInference.LlmInferenceOptions.builder()
                .setModelPath(f.absolutePath).setMaxTokens(512).build())
        return llm
    }

    fun ask(ctx: Context, question: String): String {
        val m = get(ctx) ?: return "My offline brain is not installed yet."
        val name = ctx.getSharedPreferences("j", 0).getString("name", "Shiba")?.ifBlank { "Shiba" } ?: "Shiba"
        val prompt = "<start_of_turn>user\nYou are Jarvis, a helpful voice assistant. The user's name is $name; do not say their name unless they ask. " +
            "Answer in one or two short spoken sentences, no lists." + Custom.noteBlock(ctx) + "\n$question<end_of_turn>\n<start_of_turn>model\n"
        return m.generateResponse(prompt).trim()
    }
}
